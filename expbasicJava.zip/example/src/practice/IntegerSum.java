package practice;

import java.util.Scanner;

public class IntegerSum {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int total=0;
		
		for(int i=1; i<11; i++)
		{
			System.out.print("["+i+"]������ �Է��ϼ���: ");
			int num1 = sc.nextInt();
			
			total += num1;
			
		}
		
				
		System.out.println("------------------���--------------------");
		System.out.println("�� = "+total);
		System.out.println("��� = "+total/10);
		
		sc.close();

	}

}
