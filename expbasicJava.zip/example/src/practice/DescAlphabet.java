package practice;

import java.util.Arrays;

public class DescAlphabet {

	public static void main(String[] args) {
		
		char[] arr = {'z','y','x','w','v','u','t','s','r','q','p','o','n','m','l','k','j','i','h','g','f','e','d','c','b','a'};

		for(int i =0; i<arr.length; i++) 
		{
			System.out.print(arr[i]+" ");
		}
		
	}

}
