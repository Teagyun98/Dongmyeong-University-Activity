package practice;

import java.util.Arrays;

public class ArrayMin {
	
	public static void main(String[] args) {
		
		int[] arr = {20,50,55,-7,30,57};
		int max = arr[0];
		int min = arr[0];
		
		for (int i = 0; i < arr.length; i++) 
		{
			if (arr[i] > max) {
			max = arr[i];
			}
		}
		for (int i = 0; i < arr.length; i++) 
		{
			if (arr[i] < min) {
			min = arr[i];
			}
		}
		
		System.out.println("�ִ밪 : "+max);
		System.out.println("�ּҰ� : "+min);
		
	}

}
