package practice;

public class Students {
	
	String name;
	String subject;
	int year;
	
	Students(String n, String s, int y)
	{
		name=n;
		subject=s;
		year=y;
	}
	
	public void getSubject(String sub)
	{
		subject = sub;
	}

}
