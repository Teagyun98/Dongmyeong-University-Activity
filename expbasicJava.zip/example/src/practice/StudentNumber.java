package practice;

public class StudentNumber {

	String name;
	int studentNum;
	
	StudentNumber(String n, int s)
	{
		name = n;
		studentNum = s;
		
	}
	
	String getName() {
		return name;
	}
	int getStudentNum() {
		return studentNum;
	}
	
}
