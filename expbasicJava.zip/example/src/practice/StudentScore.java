package practice;

import java.util.Scanner;

public class StudentScore {

	public static void main(String[] args) {
		
		boolean run = true;
		int studentNum = 0;
		int[] scores = null;
		
		Scanner sc = new Scanner(System.in);
		
		while(run)
		{
			System.out.println("-----------------------------------------");
			System.out.println("1.�л��� | 2.�����Է� | 3.��������Ʈ | 4.�м� | 5.����");
			System.out.println("-----------------------------------------");
			System.out.println("����> ");
			
			int num = sc.nextInt();
			
			if(num==1)
			{
				System.out.println("�л���> ");
				studentNum = sc.nextInt();
				scores = new int[studentNum];
			}else if(num==2) {
				for(int i=0; i<studentNum; i++) {
					System.out.println("����["+i+"]");
					scores[i]=sc.nextInt();
				}
			}else if(num==3) {
				for(int i=0; i<studentNum; i++) {
					System.out.println("����["+i+"]"+scores[i]);
				}
			}else if(num==4) {
				int max=0;
				int sum=0;
				
				for(int i=0; i<studentNum; i++) {
					if(scores[i]>max) {
						max=scores[i];
						sum+=scores[i];
					}
				}
				System.out.println("�ְ� ���� : "+max);
				System.out.println("��� ���� : "+(double)sum/studentNum);
			}else if(num==5) {
				run=false;
			}
			
		}System.out.println("���α׷� ����");

	}

}
