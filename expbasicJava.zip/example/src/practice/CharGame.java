package practice;

public class CharGame {
	
	String name;
	
	public void setName(String name)
	{
		this.name=name;
	}
	
	public String getName()
	{
		return name;
	}
	

}
