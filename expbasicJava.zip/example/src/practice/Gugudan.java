package practice;

public class Gugudan {

	public static void main(String[] args) {

		for (int i = 1; i<=9; i++)
			for(int a = 1; a<=9; a++)
				System.out.println(i+"��:"+i+"X"+a+"="+i*a);

	}

}
