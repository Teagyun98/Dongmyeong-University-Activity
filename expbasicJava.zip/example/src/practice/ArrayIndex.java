package practice;

import java.util.Arrays;

public class ArrayIndex {

	public static void main(String[] args) {
		
		int[] arr = {20,50,55,-7,30,57};
		
		for(int i = 0; i<6; i++)
		{
			if(arr[i]==30)
			{
				System.out.println("30�� ���� �ε��� : "+i);
			}
		}
	}
}
